# p5.play-boilerplate
Boiler plate for p5.play

Output Link

https://agsuvidha.github.io/C21_LMS_Bullets/
